<embed 
  id="flightIframe" 
  width="100%" 
  src="your-flight-search-url-here" 
  title="Flight Search" 
  frameborder="0" 
  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
  allowfullscreen>
</embed>